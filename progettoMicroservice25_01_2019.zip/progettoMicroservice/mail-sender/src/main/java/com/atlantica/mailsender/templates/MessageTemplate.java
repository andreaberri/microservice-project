package com.atlantica.mailsender.templates;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("message")
public class MessageTemplate {
	
	private String tempOne;
	private String tempTwo;
	

	public String getTempOne() {
		return tempOne;
	}

	public void setTempOne(String tempOne) {
		this.tempOne = tempOne;
	}

	public String getTempTwo() {
		return tempTwo;
	}

	public void setTempTwo(String tempTwo) {
		this.tempTwo = tempTwo;
	}
	

}
