package com.atlantica.mailsender.controller;

import javax.mail.MessagingException;
import javax.mail.SendFailedException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atlantica.mailsender.templates.MessageTemplate;
import com.atlantica.mailsender.utility.EmailService;

@RestController
public class MailController {

	@Autowired
	EmailService emailServiceImpl;
	@Autowired
	public SimpleMailMessage template;
	@Autowired
	private MessageTemplate configuration;
	
	@GetMapping("/")
	
	public String home() throws Exception {
		
		return "sending mail via springboot index page";

	}

	@GetMapping("sendMail")

	//
	public void sendMail(
			@RequestParam("to") String to, @RequestParam("kafkaMsg") String kafkaMsg) {
		
		//template.setText(configuration.getTempTwo()+"\n%s\n");
		String text = String.format(template.getText(), kafkaMsg);
		
		System.out.println("#####################################"+template.getText());
		
		try {
			emailServiceImpl.sendSimpleMessage(to, "message_queue_trigger",
					text);
		} catch (SendFailedException e) {
			System.out.println("Send Mail Failed exception");
			e.printStackTrace();
		}

	}

}
