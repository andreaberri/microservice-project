package com.atlantica.webinterfacemongodb.proxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name= "mongo-via-kafka", url="http://localhost:8100")
//@RibbonClient(name= "mongo-via-kafka")
public interface KafkaSenderServiceProxy {
	
	@GetMapping(value = "mongo-via-kafka/communication-via-kafka/producer")
	public String producer(@RequestParam("message") String message);
	
	@GetMapping(value = "mongo-via-kafka/communication-via-kafka/consumer")
	public void consumeAndSendMail(@RequestParam("to") String to);

}
