package com.atlantica.webinterfacemongodb.proxy;

import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;



@FeignClient(name= "zuul-api-gateway-server")
//@RibbonClient(name= "gs-accessing-data-mongodb, mongo-via-kafka")
public interface ZuulApiGatewayServiceProxy {
		
		@GetMapping("gs-accessing-data-mongodb/mongo-data/utenze/{numLinea}/range")
		public List<Object> retrieveMongoQueryResult 
		(@PathVariable("numLinea") String numLinea, @RequestParam("da") String da, @RequestParam("a") String a);
		
		@GetMapping(value = "/mongo-via-kafka/communication-via-kafka/producer")
		public String producer(@RequestParam("message") String message);
		
		@GetMapping(value = "/mongo-via-kafka/communication-via-kafka/consumer")
		public void consumeAndSendMail(@RequestParam("to") String to);
}
