package com.atlantica.webinterfacemongodb.model;

import java.util.Date;

import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

public class ToolForm {
	
	private String username;
	@Size(min=10, message="Inserire almeno 10 character..." )
	private String numLinea;
	private String from;
	//@DateTimeFormat(pattern = "yyyyMMddHHmmss")
	private String to;
	private String mail;
	
	public ToolForm() {		
		super();
	}
	
	public ToolForm(String username, String numLinea, String from, String to, String mail) {
		super();
		this.username = username;
		this.numLinea = numLinea;
		this.from = from;
		this.to = to;
		this.mail = mail;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getNumLinea() {
		return numLinea;
	}

	public void setNumLinea(String numLinea) {
		this.numLinea = numLinea;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	@Override
	public String toString() {
		return "ToolForm [username=" + username + ", numLinea=" + numLinea + ", from=" + from + ", to=" + to + ", mail="
				+ mail + "]";
	}
	
	
}
