package com.atlantica.webinterfacemongodb.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.atlantica.webinterfacemongodb.model.ToolForm;
import com.atlantica.webinterfacemongodb.proxy.DataMongodbServiceProxy;
import com.atlantica.webinterfacemongodb.proxy.KafkaSenderServiceProxy;

@Controller
public class ToolFormController {
	
	@Autowired
	private DataMongodbServiceProxy proxyMongo;
	
	@Autowired
	private KafkaSenderServiceProxy proxyKafka;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	private String getLoggedInUserName(ModelMap model) {

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails)
			return ((UserDetails) principal).getUsername();

		return principal.toString();
	}

	@RequestMapping(value = "/toolForm", method = RequestMethod.GET)
	public String showAddTodoPage(ModelMap model) {

		model.addAttribute("toolForm", new ToolForm(getLoggedInUserName(model), "", "", "", ""));

		return "toolForm";
	}

	@RequestMapping(value = "/toolForm", method = RequestMethod.POST)
	public String addTodo(ModelMap model, @Valid ToolForm toolForm, BindingResult result) {

		if (result.hasErrors()) {
			return "toolForm";
		}
		
		List<Object> resultQuery=proxyMongo.retrieveMongoQueryResult(toolForm.getNumLinea(), toolForm.getFrom(), toolForm.getTo());
		
		String msg="";
		for(Object resultSing:resultQuery){
			msg += resultSing.toString();
		}
		
		String kafkaMessage= proxyKafka.producer(msg);
		proxyKafka.consumeAndSendMail(toolForm.getMail());
		
		toolForm.setUsername(getLoggedInUserName(model));
		
		String finalMessage= toolForm.getUsername() + " ha inviato a " + toolForm.getMail()
							+ " il seguente messaggio: \n"+ msg + "\n con esito: " + kafkaMessage;
		model.put("finalMessage", finalMessage);

		//return "redirect:/";
		return finalMessage;
	}

}
