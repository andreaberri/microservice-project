package com.atlantica.webinterfacemongodb.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atlantica.webinterfacemongodb.model.ToolForm;
import com.atlantica.webinterfacemongodb.proxy.DataMongodbServiceProxy;
import com.atlantica.webinterfacemongodb.proxy.KafkaSenderServiceProxy;
import com.atlantica.webinterfacemongodb.proxy.ZuulApiGatewayServiceProxy;

@Controller
public class ToolFormController {
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	@Autowired
	private DataMongodbServiceProxy proxyMongo;
	
	@Autowired
	private KafkaSenderServiceProxy proxyKafka;
	
	@Autowired
	private ZuulApiGatewayServiceProxy proxyZuul;

	private String getLoggedInUserName(ModelMap model) {

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails)
			return ((UserDetails) principal).getUsername();

		return principal.toString();
	}

	@RequestMapping(value = "/toolForm", method = RequestMethod.GET)
	public String showToolFormPage(ModelMap model) {

		model.addAttribute("toolForm", new ToolForm(getLoggedInUserName(model), "", "", "", ""));

		return "toolForm";
	}

	@RequestMapping(value = "/toolForm", method = RequestMethod.POST)
	//@ResponseBody
	public String sendToolForm(ModelMap model, @Valid ToolForm toolForm, BindingResult result) {

		if (result.hasErrors()) {
			return "toolForm";
		}
		
		System.out.println("PASSO ALLA CHIAMATA:  " + toolForm.getNumLinea() +" "+  toolForm.getFrom()+ " " + toolForm.getTo());
		List<Object> resultQuery=proxyZuul.retrieveMongoQueryResult(toolForm.getNumLinea(), toolForm.getFrom(), toolForm.getTo());
		
		String msg="";
		for(Object resultSing:resultQuery){
			msg += resultSing.toString();
		}
		
		String kafkaMessage= proxyZuul.producer(msg);
		proxyZuul.consumeAndSendMail(toolForm.getMail());
		
		toolForm.setUsername(getLoggedInUserName(model));
		
		String finalMessage= toolForm.getUsername() + " ha inviato a " + toolForm.getMail() + " per la linea: "
				+ toolForm.getNumLinea() + " il seguente messaggio: \n"+ msg + "\n con esito: " + kafkaMessage;
		model.put("finalMessage", finalMessage);
		
		System.out.println("FINAL MESSAGE: " + finalMessage);

		//return "redirect:/";
		//return finalMessage;
		return "result";
	}

}
