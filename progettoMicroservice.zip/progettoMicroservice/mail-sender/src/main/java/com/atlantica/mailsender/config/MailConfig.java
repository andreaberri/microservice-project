package com.atlantica.mailsender.config;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.atlantica.mailsender.templates.MessageTemplate;

@Configuration 
public class MailConfig {

    @Value("${spring.mail.host}")
    private String host;

    @Value("${spring.mail.port}")
    private Integer port;
    
    @Value("${spring.mail.username}")
    private String user;
    
    @Value("${spring.mail.password}")
    private String password;
    
    @Autowired
	private MessageTemplate configuration;

    @Bean
    public JavaMailSender javaMailService() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

        mailSender.setHost(host);
        mailSender.setPort(port);
        
        mailSender.setUsername(user);
        mailSender.setPassword(password);

        mailSender.setJavaMailProperties(getMailProperties());

        return mailSender;
    }

    private Properties getMailProperties() {
        Properties props = new Properties();
        props.setProperty("mail.transport.protocol", "smtp");
        props.setProperty("mail.smtp.auth", "true");
        props.setProperty("mail.smtp.starttls.enable", "true");
        props.setProperty("mail.debug", "true");
        props.setProperty("mail.smtp.ssl.trust", "mx.infocloudservices.it");
        return props;
    }
     
    //imposto un template di default per la mail
	@Bean
	public SimpleMailMessage templateSimpleMessage() {
	    
		SimpleMailMessage message = new SimpleMailMessage();
		message.setText(configuration.getTempOne()+"\n%s\n");
	    return message;
	}
}
