package com.atlantica.mailsender.utility;

import javax.mail.SendFailedException;

public interface EmailService {

	   public void sendSimpleMessage (

	          String to, String subject, String text) throws SendFailedException;



	  void sendMessageWithAttachment(
			  String to, String subject, String text, String pathToAttachment) throws Exception;

	}
