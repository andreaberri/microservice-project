package com.atlantica.mailsender.templates;

import org.springframework.mail.SimpleMailMessage;

public class Message {
	
	private SimpleMailMessage message;

	
	public Message() {
		super();
	}
	
	public Message(SimpleMailMessage message) {
		super();
		this.message = message;
	}
	public SimpleMailMessage getMessage() {
		return message;
	}
	public void setMessage(SimpleMailMessage message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "Message [message=" + message + "]";
	}
	
	
}
