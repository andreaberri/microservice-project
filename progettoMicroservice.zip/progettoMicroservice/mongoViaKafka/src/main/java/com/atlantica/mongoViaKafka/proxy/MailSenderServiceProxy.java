package com.atlantica.mongoViaKafka.proxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name= "mail-sender", url="http://localhost:8200")
//@RibbonClient(name= "mail-sender")
public interface MailSenderServiceProxy {
	
	@GetMapping("mail-sender/sendMail")
	public void sendMail(
			@RequestParam("to") String to, @RequestParam("kafkaMsg") String kafkaMsg);

}
