package com.atlantica.mongoViaKafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import brave.sampler.Sampler;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients("com.atlantica.mongoViaKafka.proxy")
public class MongoViaKafkaApplication {
	
	/*@Autowired
    private MongoRepository repo;*/
	
	public static void main(String[] args) {
		SpringApplication.run(MongoViaKafkaApplication.class, args);
	}
	
	@Bean
	public Sampler defaultSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}
	
	/* @Bean
	    CommandLineRunner preLoadMongo() throws Exception {
	        return args -> {
	            //repo.doSOmethingInMongoDB
	        	};        
	 }*/
}
