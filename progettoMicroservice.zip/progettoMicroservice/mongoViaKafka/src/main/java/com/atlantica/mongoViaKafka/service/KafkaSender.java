package com.atlantica.mongoViaKafka.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaSender {
	
	private static final Logger LOG = LoggerFactory.getLogger(KafkaSender.class);
	
	@Value("${app.topic.mongo}")
	private String kafkaTopic;
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	
	public void send(String message) {
		LOG.info("sending message='{}' to topic='{}'", message, kafkaTopic);
	    kafkaTemplate.send(kafkaTopic, message);
	}

}
