package com.atlantica.mongoViaKafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atlantica.mongoViaKafka.proxy.MailSenderServiceProxy;
import com.atlantica.mongoViaKafka.service.KafkaReceiver;
import com.atlantica.mongoViaKafka.service.KafkaSender;

@RestController
@RequestMapping(value = "/communication-via-kafka/")
public class KafkaWebController {
	
	@Autowired
	KafkaSender kafkaSender;
	
	@Autowired
	KafkaReceiver kafkaReceiver;
	
	@Autowired
	MailSenderServiceProxy proxy;

	@GetMapping(value = "/producer")
	public String producer(@RequestParam("message") String message) {
		kafkaSender.send(message);

		return "Message sent to the Kafka Topic mongoLog Successfully";
	}

	@GetMapping(value = "/consumer")
	
	public void consumeAndSendMail(@RequestParam("to") String to) {
		
		String receivedMsg= kafkaReceiver.getReceivedMsg();
		proxy.sendMail(to, receivedMsg);
		
	}

}
