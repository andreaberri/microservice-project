package com.atlantica.mongoViaKafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atlantica.mongoViaKafka.proxy.MailSenderServiceProxy;
import com.atlantica.mongoViaKafka.service.KafkaReceiver;
import com.atlantica.mongoViaKafka.service.KafkaSender;

@RestController
//da commentare il request mapping altrimenti non funziona perché non viene trovato il metodo
//@RequestMapping(value = "/communication-via-kafka/")
public class KafkaWebController {
	
	@Autowired
	KafkaSender kafkaSender;
	
	@Autowired
	KafkaReceiver kafkaReceiver;
	
	@Autowired
	MailSenderServiceProxy proxy;

	@GetMapping(value = "/communication-via-kafka/producer")
	public String producer(@RequestParam("message") String message) {
		kafkaSender.send(message);

		return "Message sent to the Kafka Topic mongoLog Successfully";
	}

	
	@GetMapping(value = "/communication-via-kafka/consumer")
	
	public void consumeAndSendMail(@RequestParam("to") String to) {
		
		String receivedMsg= kafkaReceiver.getReceivedMsg();
		if(receivedMsg == null) {
			receivedMsg = "mail is been sent first of retrying kafka consumer result";
			
		}
		System.out.println("THE RECEIVED MESSAGE IS: " + receivedMsg);
		proxy.sendMail(to, receivedMsg);
		System.out.println("MAIL INVIATA");
		kafkaReceiver.setReceivedMsg("");
		
	}

}
