package com.atlantica.gsaccessingdatamongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsAccessingDataMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsAccessingDataMongodbApplication.class, args);
	}
}
