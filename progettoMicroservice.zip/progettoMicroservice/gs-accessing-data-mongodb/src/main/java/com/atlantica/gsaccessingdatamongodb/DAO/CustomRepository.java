package com.atlantica.gsaccessingdatamongodb.DAO;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.atlantica.gsaccessingdatamongodb.model.Cdrs;
import com.atlantica.gsaccessingdatamongodb.model.User;

//@RepositoryRestResource(collectionResourceRel = "traffico", path = "utenzes")
public interface CustomRepository extends MongoRepository<User, String> {

	public List<User> findAllByNumLinea (String numLinea);
	
	//@Query()
	public List<User> findByBuckettDataChiamataBetween(String from, String to);
	
	 //@Query(value="{'numLinea':?0, 'buckett.dataChiamata': {$gte:?1, $lte:?2}}", fields="{'buckett':1}")
	 @Query(value="{'numLinea':?0, 'cdrList.dataChiamata': {$gte:?1, $lte:?2}}", fields="{'numLinea':0}")
	 public List<User> findByNumLineaAndBuckettDataChiamataBetween (String numLinea, String from, String to);
	
	
	//http://localhost:8080/utenza/search/findByDataChiamataBetween?da=param?a=param
}
