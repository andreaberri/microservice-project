package com.atlantica.gsaccessingdatamongodb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.atlantica.gsaccessingdatamongodb.DAO.CustomRepository;
import com.atlantica.gsaccessingdatamongodb.model.User;

@RestController
public class MongoController {
	
	@Autowired
	private CustomRepository customRepo;
	
	@GetMapping("utenze")
	public List<User> retriveAllUser(){
		return customRepo.findAll();
		
	}
	
	@GetMapping("mongo-data/utenze/{numLinea}")
	public List<User> retriveAllUserFromNumLinea(@PathVariable String numLinea){
		return customRepo.findAllByNumLinea(numLinea);
		
	}
	
	//metodo con uri e Path Variable
/*	@GetMapping("utenze/{da}/{a}")
	public List<User> retriveAllUserFromBuckettDataChiamata(
							@PathVariable String da, @PathVariable String a){
		return customRepo.findByBuckettDataChiamataBetween(da, a);
		
	}*/
	//@RequestParam("name") String name
	@GetMapping("mongo-data/utenze/range")
	public List<User> retriveAllUserFromBuckettDataChiamata(
			@RequestParam("da") String da, @RequestParam("a") String a){
		return customRepo.findByBuckettDataChiamataBetween(da, a);
		
	}
	
	// metodo con uri range?da=data1&a=data2		 
	@GetMapping("mongo-data/utenze/{numLinea}/range")
	public List<User> retriveAllUserFromNumLineaAndRangeOfBuckettDataChiamata(
			@PathVariable String numLinea, @RequestParam("da") String da, @RequestParam("a") String a){
		return customRepo.findByNumLineaAndBuckettDataChiamataBetween(numLinea, da, a);
		
	}
}
