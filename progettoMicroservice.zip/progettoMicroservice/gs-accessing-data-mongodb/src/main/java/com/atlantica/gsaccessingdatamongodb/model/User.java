package com.atlantica.gsaccessingdatamongodb.model;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "bucketProva")
public class User {
	
	@Id
	private String id;
	private String numLinea;
	private String data;	
	@Field("cdrList")
	private ArrayList<Cdrs> buckett;
	private int count;
	
	public User() {}
	
	public User(String id, String numLinea, String data, ArrayList<Cdrs> buckett, int count) {
		super();
		this.id = id;
		this.numLinea = numLinea;
		this.data = data;
		this.buckett = buckett;
		this.count = count;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNumLinea() {
		return numLinea;
	}
	public void setNumLinea(String numLinea) {
		this.numLinea = numLinea;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public ArrayList<Cdrs> getBuckett() {
		return buckett;
	}
	public void setBuckett(ArrayList<Cdrs> buckett) {
		this.buckett = buckett;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", numLinea=" + numLinea + ", data=" + data + ", buckett=" + buckett + ", count="
				+ count + "]";
	}
	
	
	

}
