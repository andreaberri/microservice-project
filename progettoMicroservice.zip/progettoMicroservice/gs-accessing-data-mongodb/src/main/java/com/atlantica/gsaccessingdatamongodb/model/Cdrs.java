package com.atlantica.gsaccessingdatamongodb.model;

import org.springframework.stereotype.Component;

@Component
public class Cdrs {
	
	private String apn;               
	private String centrale;          
	private String cin;               
	private String classeServizio;    
	private String codiceOfferta;     
	private Double costo;             
	private String dataChiamata;      
	private String dataFatturazione;  
	private Double durataChiamata;    
	private String identificativoSIM; 
	private String macroFamiglia;     
	private String numChiamato;       
	private String numChiamatoCifrato;
	private String profiloTariffario; 
	private String tipoCartaServizi2; 
	private String tipoChiamata;      
	private String tipoComunicazione; 
	private String tipoTicket;        
	private Long volumeDati;
	
	public Cdrs() {}
	
	public Cdrs(String apn, String centrale, String cin, String classeServizio, String codiceOfferta, Double costo,
			String dataChiamata, String dataFatturazione, Double durataChiamata, String identificativoSIM,
			String macroFamiglia, String numChiamato, String numChiamatoCifrato, String profiloTariffario,
			String tipoCartaServizi2, String tipoChiamata, String tipoComunicazione, String tipoTicket,
			Long volumeDati) {
		super();
		this.apn = apn;
		this.centrale = centrale;
		this.cin = cin;
		this.classeServizio = classeServizio;
		this.codiceOfferta = codiceOfferta;
		this.costo = costo;
		this.dataChiamata = dataChiamata;
		this.dataFatturazione = dataFatturazione;
		this.durataChiamata = durataChiamata;
		this.identificativoSIM = identificativoSIM;
		this.macroFamiglia = macroFamiglia;
		this.numChiamato = numChiamato;
		this.numChiamatoCifrato = numChiamatoCifrato;
		this.profiloTariffario = profiloTariffario;
		this.tipoCartaServizi2 = tipoCartaServizi2;
		this.tipoChiamata = tipoChiamata;
		this.tipoComunicazione = tipoComunicazione;
		this.tipoTicket = tipoTicket;
		this.volumeDati = volumeDati;
	}


	public String getApn() {
		return apn;
	}
	public void setApn(String apn) {
		this.apn = apn;
	}
	public String getCentrale() {
		return centrale;
	}
	public void setCentrale(String centrale) {
		this.centrale = centrale;
	}
	public String getCin() {
		return cin;
	}
	public void setCin(String cin) {
		this.cin = cin;
	}
	public String getClasseServizio() {
		return classeServizio;
	}
	public void setClasseServizio(String classeServizio) {
		this.classeServizio = classeServizio;
	}
	public String getCodiceOfferta() {
		return codiceOfferta;
	}
	public void setCodiceOfferta(String codiceOfferta) {
		this.codiceOfferta = codiceOfferta;
	}
	public Double getCosto() {
		return costo;
	}
	public void setCosto(Double costo) {
		this.costo = costo;
	}
	public String getDataChiamata() {
		return dataChiamata;
	}
	public void setDataChiamata(String dataChiamata) {
		this.dataChiamata = dataChiamata;
	}
	public String getDataFatturazione() {
		return dataFatturazione;
	}
	public void setDataFatturazione(String dataFatturazione) {
		this.dataFatturazione = dataFatturazione;
	}
	public Double getDurataChiamata() {
		return durataChiamata;
	}
	public void setDurataChiamata(Double durataChiamata) {
		this.durataChiamata = durataChiamata;
	}
	public String getIdentificativoSIM() {
		return identificativoSIM;
	}
	public void setIdentificativoSIM(String identificativoSIM) {
		this.identificativoSIM = identificativoSIM;
	}
	public String getMacroFamiglia() {
		return macroFamiglia;
	}
	public void setMacroFamiglia(String macroFamiglia) {
		this.macroFamiglia = macroFamiglia;
	}
	public String getNumChiamato() {
		return numChiamato;
	}
	public void setNumChiamato(String numChiamato) {
		this.numChiamato = numChiamato;
	}
	public String getNumChiamatoCifrato() {
		return numChiamatoCifrato;
	}
	public void setNumChiamatoCifrato(String numChiamatoCifrato) {
		this.numChiamatoCifrato = numChiamatoCifrato;
	}
	public String getProfiloTariffario() {
		return profiloTariffario;
	}
	public void setProfiloTariffario(String profiloTariffario) {
		this.profiloTariffario = profiloTariffario;
	}
	public String getTipoCartaServizi2() {
		return tipoCartaServizi2;
	}
	public void setTipoCartaServizi2(String tipoCartaServizi2) {
		this.tipoCartaServizi2 = tipoCartaServizi2;
	}
	public String getTipoChiamata() {
		return tipoChiamata;
	}
	public void setTipoChiamata(String tipoChiamata) {
		this.tipoChiamata = tipoChiamata;
	}
	public String getTipoComunicazione() {
		return tipoComunicazione;
	}
	public void setTipoComunicazione(String tipoComunicazione) {
		this.tipoComunicazione = tipoComunicazione;
	}
	public String getTipoTicket() {
		return tipoTicket;
	}
	public void setTipoTicket(String tipoTicket) {
		this.tipoTicket = tipoTicket;
	}
	public Long getVolumeDati() {
		return volumeDati;
	}
	public void setVolumeDati(Long volumeDati) {
		this.volumeDati = volumeDati;
	}
	@Override
	public String toString() {
		return "Cdrs [apn=" + apn + ", centrale=" + centrale + ", cin=" + cin + ", classeServizio=" + classeServizio
				+ ", codiceOfferta=" + codiceOfferta + ", costo=" + costo + ", dataChiamata=" + dataChiamata
				+ ", dataFatturazione=" + dataFatturazione + ", durataChiamata=" + durataChiamata
				+ ", identificativoSIM=" + identificativoSIM + ", macroFamiglia=" + macroFamiglia + ", numChiamato="
				+ numChiamato + ", numChiamatoCifrato=" + numChiamatoCifrato + ", profiloTariffario="
				+ profiloTariffario + ", tipoCartaServizi2=" + tipoCartaServizi2 + ", tipoChiamata=" + tipoChiamata
				+ ", tipoComunicazione=" + tipoComunicazione + ", tipoTicket=" + tipoTicket + ", volumeDati="
				+ volumeDati + "]";
	}
	
	
	

}
